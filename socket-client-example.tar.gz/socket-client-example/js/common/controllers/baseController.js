function baseCtrl($scope, $http, $location, $rootScope, debug, sockets, AppState) {

    $scope.load = function() {
        $scope.title = "socket.io usage example";
        $scope.socketStatus = "Socket Disconnected";
        $scope.socketMessage = "";
    }

    $scope.connect2Socket = function() {
        debug.log('will connect to sockets: ', AppState.socket_io.url);
        sockets.connect();      
    }

    //despacha uma mensagem em socket
    $scope.sendSocketMessage = function() {
        var msg = {"user" :  AppState.user.id, "evento" : {myevent: "foo"}};
        debug.log('sending message via socket: ', msg);


        sockets.emmit(msg);
    }

    //recebe uma mensagem por sockets
    $rootScope.$on("socketMessage", function(evt, event) {
        debug.log('socket event received: ', event);      

        $scope.socketMessage = JSON.stringify(event);

    })


    $scope.load();


}
