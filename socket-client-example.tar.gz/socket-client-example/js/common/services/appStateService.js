'use strict';

angular.module('app.appState', [])
//AppState é para o rootScope não virar a casa da mãe joana
.factory('AppState', function() {return {}})