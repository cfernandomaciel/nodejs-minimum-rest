'use strict';

angular.module('app.sockets', [])

.factory('sockets', function(AppState, $rootScope, debug) {
    return {
        socket : {},
        connect : function () {                        
            this.socket = io.connect(AppState.socket_io.url);
            this.socket.on('message', function (data) {
                $rootScope.$broadcast("socketMessage", data);
            });            
        },
        emmit : function(msg) {
            this.socket.emit('send', { message: msg });
        }
    }
})