'use strict';



var config_json = {
    "restUrl" : "http:\/\/10.0.3.34",
    /*"restUrl" : "http:\/\/localhost\\:4000\/api\/v1\/",*/    
    "apiVersion" : "v1",        
    "socketIOPort" : "3700",
     "user" : {
         "id" : 1424,
         "email" : "claudio.fernando@gmail.com"
         ,"password" : "spitz01"
         , "authentication_token" : "z4X9iyzKvStGL6mcDC2y"         

     },   
    "debug_mode" : true
    

}


angular.module('app', [
    'app.appState',   
    'app.debug',
    'app.sockets'
    //componentes AngularJS
    ,'ngResource'
]).

    config(['$httpProvider', '$routeProvider', '$locationProvider',
        function($httpProvider, $routeProvider, $locationProvider) {


        $httpProvider.defaults.withCredentials = true;
        $httpProvider.defaults.useXDomain = true;
        delete $httpProvider.defaults.headers.common['X-Requested-With'];

        $routeProvider.
            when('/home', {templateUrl: 'views/home.tpl.html', controller: 'baseCtrl'}).
            otherwise({redirectTo: '/home'});
    }])
    .run(function($http, AppState, $rootScope, debug) {

        AppState.config = {};        
        AppState.debug_mode = config_json.debug_mode;               

        AppState.socket_io = {};
        AppState.socket_io.url = config_json.restUrl+":"+config_json.socketIOPort;        
        console.log('socket url: ', AppState.socket_io.url);

        AppState.user = {};
        AppState.user.id = "43274621546125";
    })
